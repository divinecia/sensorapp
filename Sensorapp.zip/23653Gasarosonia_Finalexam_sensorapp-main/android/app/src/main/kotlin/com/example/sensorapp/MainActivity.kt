package com.example.sensorapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
